#!/usr/bin/env bash
# Clone + install the DESi stack, verify the gate. Idempotent.
set -euo pipefail
ROOT="${DESI_ROOT:-/home/claude}"
cd "$ROOT"
for r in DESi DESi-Paper-Review Joni; do
  [ -d "$r" ] || git clone -q --depth 1 "https://github.com/hstre/$r.git"
done
pip install -q -e ./DESi --break-system-packages
pip install -q -e ./DESi-Paper-Review --break-system-packages
mkdir -p "$ROOT/desi-run"
echo "--- doctor ---"
desi-paper-review doctor
echo "--- joni importable ---"
PYTHONPATH="$ROOT/Joni/src" python3 -c \
  "from joni.autonomy.pdf import claim_sentences; print('joni.claim_sentences ok')"
echo "workdir: $ROOT/desi-run"
