"""Emit a governed adjudication artifact from Claude's in-chat verdicts.

No API calls, no key, no cost. Claude writes verdicts.json; this canonicalizes and
hashes it through DESi's real replay kernel and enforces the core gate.

    python3 emit.py <ledger.json> <verdicts.json> [out.json]

verdicts.json:
  {"claude_interest": "none|topic_adjacent|direct",
   "interest_note": "...",                      # required when interest != none
   "structural": {"load_bearing": "...", "falsifiability": "...",
                  "unaddressed_objection": "...", "what_holds": "..."},
   "claims": {"C002": ["NOT_A_CLAIM", "rhetorical"], ...}}
"""
from __future__ import annotations
import hashlib, json, sys

from desi.core.replay_kernel import canonical_json, replay_hash
from desi.core.governance_core import core_identity

VERDICTS = {"SUPPORTED", "OVERSTATED", "UNSUPPORTED", "NOT_A_CLAIM"}
STRONG = ("main_claim", "result_claim", "novelty_claim", "generalization_claim")

if core_identity() != 1.0:
    sys.exit("GATE FAIL: core_identity != 1.0 - refusing to emit")
if len(sys.argv) < 3:
    sys.exit(__doc__)

ledger = json.load(open(sys.argv[1]))
v = json.load(open(sys.argv[2]))
out_path = sys.argv[3] if len(sys.argv) > 3 else "adjudication.json"

strong = [c["claim_id"] for c in ledger["claims"] if c["category"] in STRONG]
given, missing = set(v["claims"]), [c for c in strong if c not in v["claims"]]
if missing:
    sys.exit(f"GATE FAIL: no verdict for {missing} - every strong claim needs one")
bad = {k: x[0] for k, x in v["claims"].items() if x[0] not in VERDICTS}
if bad:
    sys.exit(f"GATE FAIL: verdict not in schema: {bad}")
if v["claude_interest"] != "none" and not v.get("interest_note"):
    sys.exit("GATE FAIL: interest != none requires interest_note")

tally = {k: sum(1 for x in v["claims"].values() if x[0] == k) for k in sorted(VERDICTS)}
artifact = {
    "tool": "desi-review/claude-as-engine",
    "engine": {"kind": "in_conversation_llm", "provider": "anthropic",
               "api_calls": 0, "cost": "none beyond the chat itself"},
    "provenance": "adjudication layer is NOT part of hstre/DESi",
    "source_ledger_replay_hash": ledger["replay_hash"],
    "ledger_sha256": hashlib.sha256(
        canonical_json(ledger["claims"]).encode()).hexdigest(),
    "claude_interest": v["claude_interest"],
    "interest_note": v.get("interest_note", ""),
    "governance": {"core_identity": core_identity(), "replay_stable": False,
                   "replay_note": ("An LLM verdict is not reproducible. The hash fixes "
                                   "THIS adjudication's bytes only."),
                   "disclaimer": ledger["governance"]["disclaimer"]},
    "structural": v["structural"],
    "claims": {k: {"verdict": x[0], "reason": x[1]} for k, x in sorted(v["claims"].items())},
    "tally": tally,
    "strong_claims": len(strong),
    "verdict": "REVIEW_ASSISTANCE_ONLY",
}
artifact["run_hash"] = replay_hash(canonical_json(artifact))
open(out_path, "w").write(canonical_json(artifact))
print(f"{out_path}  run_hash {artifact['run_hash'][:16]}  {tally}")
