"""Bridge: DESi deterministic claim ledger -> live LLM adjudication (DeepSeek).

NOT part of hstre/DESi. Uses only the real public API:
  desi.core.replay_kernel.canonical_json / replay_hash
  desi.core.governance_core.core_identity   (emission gate)
  desi.scientific_rendering.forbidden_hits
  desi.deepseek_client.DeepSeekClient / ChatMessage
  desi.config.load_config
API key is read from env only; never written to any file or artifact.
"""
from __future__ import annotations
import json, os, sys, hashlib

from desi.core.replay_kernel import canonical_json, replay_hash
from desi.core.governance_core import core_identity
from desi.config import load_config
from desi.deepseek_client import DeepSeekClient, ChatMessage

MODEL = os.environ.get("DEEPSEEK_MODEL", "deepseek-v4-pro")
if len(sys.argv) < 3:
    sys.exit("usage: bridge.py <paper.md> <artifact.json> [out.json]")
OUT = sys.argv[3] if len(sys.argv) > 3 else "bridge_artifact.json"

if core_identity() != 1.0:
    sys.exit("GATE FAIL: core_identity != 1.0 - refusing to emit")

ledger = json.load(open(sys.argv[2]))
paper  = open(sys.argv[1]).read()
claims = ledger["claims"]
strong = [c for c in claims if c["category"] in
          ("main_claim", "result_claim", "novelty_claim", "generalization_claim")]

cfg = load_config()
client = DeepSeekClient(cfg)

SYS = ("You are an adversarial scientific reviewer. You are terse, specific and "
       "unimpressed by rhetoric. You never soften a finding to be agreeable and "
       "never inflate one to seem rigorous. If something is well supported, you "
       "say so plainly. Output only what is asked for, no preamble.")

def ask(prompt, max_tokens=6000):
    return client.chat(
        [ChatMessage("system", SYS), ChatMessage("user", prompt)],
        model=MODEL, temperature=0.0, max_tokens=max_tokens)

# --- Pass 1: structural audit of the load-bearing inference -----------------
p1 = f"""Read this article in full, then answer. Do not summarise it back to me.

1. LOAD-BEARING INFERENCE: identify the single inferential step the whole
   conclusion depends on. Quote it in under 15 words. State whether it is
   argued for or assumed.
2. FALSIFIABILITY: state what observation, if made, the article's own framework
   would count as evidence AGAINST its thesis. If no such observation exists,
   say so and show why.
3. STRONGEST UNADDRESSED OBJECTION: the most serious objection a competent
   critic would raise that the article does not engage at all. One paragraph.
4. WHERE IT IS RIGHT: the single strongest, best-supported point in the piece,
   and why it holds. Do not be generous; name only what actually survives.

--- ARTICLE ---
{paper}
--- END ARTICLE ---"""

# --- Pass 2: per-claim adjudication over the deterministic ledger -----------
claim_lines = "\n".join(f'{c["claim_id"]} [{c["category"]}] {c["text"][:400]}'
                        for c in strong)
p2 = f"""Below is a deterministically extracted ledger of the STRONG claims from
the article you just have in front of you (full text repeated after the ledger).

For EACH claim id, output exactly one line:
  <id> | SUPPORTED | OVERSTATED | UNSUPPORTED | NOT_A_CLAIM | <max 20 words why>

SUPPORTED = the cited evidence, as described, licenses the claim as stated.
OVERSTATED = there is real evidence but the wording exceeds it.
UNSUPPORTED = no evidence given or evidence does not bear on the claim.
NOT_A_CLAIM = extraction artifact, definitional, or rhetorical.

Judge only the gap between claim and evidence. Do not judge whether AI is sentient.

--- LEDGER ---
{claim_lines}
--- END LEDGER ---

--- ARTICLE ---
{paper}
--- END ARTICLE ---"""

print(f"[bridge] model={MODEL} strong_claims={len(strong)} total_claims={len(claims)}",
      flush=True)
out = {}
for name, prompt in (("structural_audit", p1), ("claim_adjudication", p2)):
    print(f"[bridge] running {name} ...", flush=True)
    out[name] = ask(prompt)
    print(f"[bridge]   {len(out[name])} chars", flush=True)

artifact = {
    "tool": "desi-bridge-live-llm",
    "bridge_provenance": "NOT part of hstre/DESi; built for this run over the real public API",
    "source_ledger_replay_hash": ledger["replay_hash"],
    "paper_sha256": hashlib.sha256(paper.encode()).hexdigest(),
    "llm": {"provider": "deepseek", "model": MODEL, "temperature": 0.0,
            "api_key_env": "DEEPSEEK_API_KEY"},
    "governance": {"core_identity": core_identity(),
                   "live_calls_enabled": True,
                   "replay_stable": False,
                   "replay_note": ("LLM output is NOT replay-stable. The hash below "
                                   "fixes THIS run's bytes only, not reproducibility."),
                   "disclaimer": ledger["governance"]["disclaimer"],
                   "forbidden_term_hits": ledger["governance"]["forbidden_term_hits"]},
    "strong_claims_submitted": len(strong),
    "results": out,
    "verdict": "REVIEW_ASSISTANCE_ONLY",
}
artifact["run_hash"] = replay_hash(canonical_json(artifact))
open(OUT, "w").write(canonical_json(artifact))
print("[bridge] run_hash", artifact["run_hash"][:16])
