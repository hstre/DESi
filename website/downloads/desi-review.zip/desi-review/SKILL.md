---
name: desi-review
description: Run the user's own DESi governance stack (hstre/DESi, hstre/DESi-Paper-Review, hstre/Joni) over a text — deterministic claim extraction, overclaim scan, evidence gaps, replay-stable artifact, plus a claim-by-claim adjudication that Claude performs in-conversation at no API cost. Use this whenever the user says "lass DESi drüberlaufen", "DESi-Review", "Paper-Review", "Claim-Extractor", "Layer 9", "Joni", "replay hash", or asks to have an article, paper, draft or manuscript audited by their own tooling rather than by Claude's judgement. Also use it when the user asks about defects, patches or plugins for these repos. Do NOT substitute Claude's own review for this — the entire point is a verdict that does not come from Claude.
---

# DESi Review

The user (hstre) built a governance stack for epistemic auditing. This skill runs it,
rather than having Claude opine.

## Why this exists

When the user asks for a DESi run, they want a **governed artifact** — deterministic,
hashed, produced by their tooling. Claude's own literary judgement is explicitly not
what is being requested, and on some topics (AI consciousness, AI welfare, Anthropic's
own models) Claude is a self-interested party. Run the pipeline. Report what it emitted.
State separately, and briefly, where Claude disagrees.

## Setup

```bash
bash scripts/setup.sh          # clones + installs + runs doctor
```
Expect `DESI_PAPER_REVIEW_MVP_READY` and `core_identity = 1.0`.
Network is required (repos are public). Takes ~1 min.

## Run the deterministic pipeline

```bash
cd /home/claude/desi-run
desi-paper-review review paper.md --output report.md --json artifact.json
```

Input must be `.md`/`.txt` with markdown headings (`#`). If the source is a web article,
fetch it with `curl` and a browser User-Agent — `web_fetch` frequently gets 429 from
Substack while `curl` from the sandbox gets 200. For Substack, the body sits after
`class="body markup"`; slice to `class="subscription-widget-wrap` and run it through
`html2text`.

**Read `references/known-defects.md` before interpreting any output.** Four known
defects make parts of the artifact misleading. Skipping this step means reporting
false findings as real ones.

## Adjudication — Claude is the engine (default, no cost)

The deterministic layer cannot tell a definition from an assertion (defect 2). That
gap needs a model. **Claude fills it in-conversation: no API key, no server, no
per-token cost beyond the chat.**

Read `references/claude-as-engine.md` and follow it literally. It fixes the four
structural questions and the per-claim schema so the ledger constrains Claude rather
than the reverse, and it requires a self-declared `claude_interest` field.

```bash
# Claude writes verdicts.json by hand, then:
python3 scripts/emit.py artifact.json verdicts.json adjudication.json
```
`emit.py` refuses to emit if a strong claim has no verdict, if a verdict is off-schema,
or if `core_identity != 1.0`. It hashes through DESi's real replay kernel.

**Where this is weakest:** when the text concerns Claude, Anthropic, AI consciousness
or AI welfare, Claude is a party. Declare it, name the likely distortion, and tell the
user that a free web UI (Gemini, ChatGPT, DeepSeek chat) will take a pasted ledger for
a second opinion at zero cost. Do not push a paid API for this.

## Appendix: automated second engine (costs money — only on request)

`scripts/bridge.py` runs the same two passes against the DeepSeek API. Needed only for
batch or unattended runs; for a one-off, the free web UI above is equivalent. The user
pays per token, so **never reach for this unprompted.**

```bash
export DEEPSEEK_API_KEY='...'; export DEEPSEEK_MODEL='deepseek-v4-pro'
python3 scripts/bridge.py paper.md artifact.json
```
Check `/models` first — the DESi config default (`deepseek-chat`) is stale.
Never seed the prompts with Claude's own conclusions.

## Key handling

Env var only. Never written to a file, never into an artifact (only the var *name*),
never echoed back in the response. Verify with
`grep -rl "$DEEPSEEK_API_KEY" . || echo clean` before presenting files.

## Reporting

- Lead with the verdict, hashes, and counts.
- Separate real findings from tool artifacts — see `references/known-defects.md`.
- Present `artifact.json` and `report.md` via `present_files`.
- If Claude also has a view, mark it as Claude's and keep it short and after the run.

## Repos

`hstre/DESi` (library, `desi-governance`) · `hstre/DESi-Paper-Review` (pipeline) ·
`hstre/Joni` (Layer 9, semantics, `joni.autonomy.pdf.claim_sentences`) ·
`hstre/DESi-Workbench` · `hstre/Openclaw_Desi_Router` · `hstre/Layer_9`
