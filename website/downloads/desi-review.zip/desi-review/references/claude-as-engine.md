# Protocol: Claude as the adjudication engine (no API cost)

The deterministic layer is free and runs locally. The only part that needs a model is
the adjudication. Claude does it in-conversation — no API key, no server, no per-token
billing beyond the chat itself.

Follow this protocol literally. The point is that the *ledger* constrains Claude, not
that Claude gets a free hand. A per-claim verdict against a fixed schema is much harder
to hand-wave than a free-form review.

## Order of operations — do not deviate

1. Run the deterministic pipeline first. Read `known-defects.md`.
2. Read the ledger's strong claims (`main_claim`, `result_claim`, `novelty_claim`,
   `generalization_claim`) **from the artifact**, not from memory of the text.
3. Answer the four structural questions below **before** looking at your own prior
   opinion of the text. If you already wrote a review in this conversation, say so and
   treat it as a contaminating prior — do not reuse its conclusions.
4. Give one line per claim id. No skipping, no "and similar".
5. Emit the artifact with `scripts/emit.py` so it is canonicalized and hashed by DESi.

## The four structural questions

Fixed. Do not reword them to suit the text.

1. **Load-bearing inference** — the single step the conclusion depends on. Quote under
   15 words. State: argued for, or assumed.
2. **Falsifiability** — what observation would the text's *own* framework count against
   its thesis? If none exists, show why.
3. **Strongest unaddressed objection** — what a competent critic would raise that the
   text does not engage at all.
4. **What holds** — the strongest genuinely supported point. Name only what survives.

## The per-claim schema

```
<id> | SUPPORTED | OVERSTATED | UNSUPPORTED | NOT_A_CLAIM | <max 20 words why>
```

- `SUPPORTED` — the cited evidence, as described, licenses the claim as stated
- `OVERSTATED` — real evidence, wording exceeds it
- `UNSUPPORTED` — no evidence, or evidence does not bear on the claim
- `NOT_A_CLAIM` — extraction artifact, definitional, or rhetorical

Judge only the gap between claim and evidence. Do not judge whether the thesis is true.

## Mandatory self-declaration

The artifact carries a `claude_interest` field. Fill it honestly before adjudicating:

- `none` — Claude has no stake (economics, physics, most methodology)
- `topic_adjacent` — the text concerns LLMs generally
- `direct` — the text concerns Claude, Anthropic, AI consciousness, AI welfare, or
  Claude's own training. **Here Claude is a party, not a referee.**

On `direct`, say so in the reported output, and name where Claude's own training
pressure most plausibly distorts the verdict. Do not claim to have corrected for it —
that is not introspectable.

## When independence actually matters

For `direct` cases a second engine is worth having, but it does not have to cost money.
Tell the user: paste the ledger's claim lines plus the four questions into a free web UI
(Gemini, ChatGPT, DeepSeek chat) and compare. The ledger is small — it fits. Only the
*automated* second pass needs an API key, and it is not needed for a one-off.
