# Known defects in DESi-Paper-Review

Measured 2026-07-27 on a ~12k-word synthesis essay (EN original + DE translation).
Do not report affected outputs as findings without the caveat.

## 1. Silent language blindness — the worst one

All scanners are English regex lexica (`claim_extractor.py`,
`scientific_rendering.forbidden_hits`). On non-English input the pipeline finds
nothing and reports **`0 overclaims`, `0 evidence gaps`** — indistinguishable from a
clean bill of health. The replay hash is byte-stable over an empty result.

Measured, same article: **69 claims (EN) vs 2 (DE)**. Forbidden hits: 3 vs 0.

**Always run on the source language.** If only a translation exists, say the run is
non-informative rather than reporting zeros.

## 2. No definition/assertion gate

The extractor labels any declarative sentence a claim. Definitions become
`main_claim`. There is no `NOT_A_CLAIM` outcome in the schema, so definitional
sentences have nowhere to go but into the findings.

Measured: of 25 "strong claims", an LLM adjudicator classified **13 as NOT_A_CLAIM**
(definitions, setup description, rhetoric). Only 4 were real defects
(2 unsupported, 2 overstated); 8 were genuinely supported.

Joni's `claim_sentences` has the same hole — its `_VERB` regex includes
`is|are|was|were|be`, so definitions match by construction. Measured: 8 of those 13
pass through Joni too. What Joni fixed is not the regex but the extractor's *status* —
it only nominates candidates; the Semantic Layer decides. `pdf.py` docstring and
`candidate_extractor.py` ("It draws **no** conclusions"), plus the S0 rule from the
research diary: *"der Extraktor rät nie"*.

DESi already has the vocabulary that Paper-Review skips: `memory/claim.py` and
`logic/audit.py` define `UNDER_LOGICAL_AUDIT` → `GAP_DETECTED` / `BRIDGE_REQUIRED` /
`LOGICALLY_SUPPORTED` / `LOGICALLY_REJECTED`.

## 3. `solves` is a useless overclaim term

`OVERCLAIM_TERMS` includes `solves`, matching "solve problems", "problem-solving",
"solving math". On any text about reasoning this is nearly all false positives.
Measured: most of 17 flagged overclaims were noise.

## 4. Reproducibility risks fire on non-empirical texts

`missing_code` / `missing_data` / `missing_parameters` / `unclear_dataset` /
`unsupported_metrics` are emitted unconditionally. A synthesis essay or position paper
gets all five by construction. That is a genre mismatch, not a finding about the text.

## What is actually reliable

- Claim **taxonomy distribution** (esp. the limitation_claim ratio — a low share is a
  real signal on a text making strong claims)
- `forbidden_term_hits` from `scientific_rendering` on English input
- Replay stability of the deterministic layer (verified: identical hash on re-run)
- The governance gate (`core_identity == 1.0`, refuses to emit otherwise)
